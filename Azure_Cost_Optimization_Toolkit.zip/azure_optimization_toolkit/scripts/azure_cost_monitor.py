#!/usr/bin/env python3
"""
Azure Cost Monitor - Real-time cost monitoring and optimization automation
Part of CloudCostChefs Azure Cost Optimization Toolkit

This script provides comprehensive Azure cost monitoring, anomaly detection,
and automated optimization recommendations with ServiceNow integration.
"""

import json
import logging
import os
import sys
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple

import requests
from azure.identity import DefaultAzureCredential
from azure.mgmt.consumption import ConsumptionManagementClient
from azure.mgmt.costmanagement import CostManagementClient
from azure.mgmt.monitor import MonitorManagementClient
from azure.mgmt.resource import ResourceManagementClient
from azure.mgmt.compute import ComputeManagementClient

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('azure_cost_monitor.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

class AzureCostMonitor:
    """
    Azure Cost Monitor for real-time cost tracking and optimization
    """
    
    def __init__(self, subscription_id: str, config_file: str = 'config/monitor_config.json'):
        """
        Initialize Azure Cost Monitor
        
        Args:
            subscription_id: Azure subscription ID
            config_file: Path to configuration file
        """
        self.subscription_id = subscription_id
        self.config = self._load_config(config_file)
        
        # Initialize Azure clients
        self.credential = DefaultAzureCredential()
        self.cost_client = CostManagementClient(self.credential)
        self.consumption_client = ConsumptionManagementClient(self.credential, subscription_id)
        self.monitor_client = MonitorManagementClient(self.credential, subscription_id)
        self.resource_client = ResourceManagementClient(self.credential, subscription_id)
        self.compute_client = ComputeManagementClient(self.credential, subscription_id)
        
        logger.info(f"Initialized Azure Cost Monitor for subscription: {subscription_id}")
    
    def _load_config(self, config_file: str) -> Dict:
        """Load configuration from JSON file"""
        try:
            with open(config_file, 'r') as f:
                config = json.load(f)
            logger.info(f"Loaded configuration from {config_file}")
            return config
        except FileNotFoundError:
            logger.warning(f"Config file {config_file} not found, using defaults")
            return self._get_default_config()
        except json.JSONDecodeError as e:
            logger.error(f"Error parsing config file: {e}")
            return self._get_default_config()
    
    def _get_default_config(self) -> Dict:
        """Get default configuration"""
        return {
            "thresholds": {
                "daily_spend_increase": 20.0,
                "monthly_budget_percentage": 80.0,
                "cpu_utilization_threshold": 20.0,
                "memory_utilization_threshold": 30.0
            },
            "notifications": {
                "email": "finops@company.com",
                "slack_webhook": "",
                "servicenow_enabled": False
            },
            "servicenow": {
                "instance_url": "",
                "username": "",
                "password": "",
                "table_name": "incident"
            },
            "optimization": {
                "auto_rightsizing": False,
                "auto_cleanup": True,
                "auto_shutdown": True
            }
        }
    
    def get_current_costs(self, days: int = 30) -> Dict:
        """
        Get current cost data for the specified period
        
        Args:
            days: Number of days to analyze
            
        Returns:
            Dictionary containing cost data
        """
        try:
            end_date = datetime.now()
            start_date = end_date - timedelta(days=days)
            
            # Query cost data using Cost Management API
            scope = f"/subscriptions/{self.subscription_id}"
            
            query_definition = {
                "type": "ActualCost",
                "timeframe": "Custom",
                "timePeriod": {
                    "from": start_date.strftime("%Y-%m-%dT00:00:00Z"),
                    "to": end_date.strftime("%Y-%m-%dT23:59:59Z")
                },
                "dataset": {
                    "granularity": "Daily",
                    "aggregation": {
                        "totalCost": {
                            "name": "PreTaxCost",
                            "function": "Sum"
                        }
                    },
                    "grouping": [
                        {
                            "type": "Dimension",
                            "name": "ServiceName"
                        }
                    ]
                }
            }
            
            # Execute query
            result = self.cost_client.query.usage(scope, query_definition)
            
            # Process results
            total_cost = 0
            daily_costs = {}
            service_costs = {}
            
            for row in result.rows:
                cost = float(row[0])
                date = row[1]
                service = row[2] if len(row) > 2 else "Unknown"
                
                total_cost += cost
                
                if date not in daily_costs:
                    daily_costs[date] = 0
                daily_costs[date] += cost
                
                if service not in service_costs:
                    service_costs[service] = 0
                service_costs[service] += cost
            
            return {
                "total_cost": total_cost,
                "daily_costs": daily_costs,
                "service_costs": service_costs,
                "period_days": days,
                "average_daily_cost": total_cost / days if days > 0 else 0
            }
            
        except Exception as e:
            logger.error(f"Error getting current costs: {e}")
            return {}
    
    def detect_cost_anomalies(self, cost_data: Dict) -> List[Dict]:
        """
        Detect cost anomalies based on historical patterns
        
        Args:
            cost_data: Cost data from get_current_costs()
            
        Returns:
            List of detected anomalies
        """
        anomalies = []
        
        try:
            daily_costs = cost_data.get("daily_costs", {})
            if len(daily_costs) < 7:
                logger.warning("Insufficient data for anomaly detection")
                return anomalies
            
            # Calculate baseline (average of first 80% of data)
            sorted_dates = sorted(daily_costs.keys())
            baseline_end = int(len(sorted_dates) * 0.8)
            baseline_costs = [daily_costs[date] for date in sorted_dates[:baseline_end]]
            baseline_avg = sum(baseline_costs) / len(baseline_costs)
            
            # Check recent days for anomalies
            threshold = self.config["thresholds"]["daily_spend_increase"]
            recent_dates = sorted_dates[baseline_end:]
            
            for date in recent_dates:
                daily_cost = daily_costs[date]
                increase_percentage = ((daily_cost - baseline_avg) / baseline_avg) * 100
                
                if increase_percentage > threshold:
                    anomalies.append({
                        "type": "daily_spend_increase",
                        "date": date,
                        "cost": daily_cost,
                        "baseline": baseline_avg,
                        "increase_percentage": increase_percentage,
                        "severity": "high" if increase_percentage > threshold * 2 else "medium"
                    })
            
            # Check service-level anomalies
            service_costs = cost_data.get("service_costs", {})
            total_cost = cost_data.get("total_cost", 0)
            
            for service, cost in service_costs.items():
                percentage = (cost / total_cost) * 100 if total_cost > 0 else 0
                
                # Flag services consuming >30% of total cost
                if percentage > 30:
                    anomalies.append({
                        "type": "high_service_cost",
                        "service": service,
                        "cost": cost,
                        "percentage": percentage,
                        "severity": "medium"
                    })
            
            logger.info(f"Detected {len(anomalies)} cost anomalies")
            return anomalies
            
        except Exception as e:
            logger.error(f"Error detecting cost anomalies: {e}")
            return []
    
    def get_optimization_recommendations(self) -> List[Dict]:
        """
        Get optimization recommendations for Azure resources
        
        Returns:
            List of optimization recommendations
        """
        recommendations = []
        
        try:
            # Get VM optimization recommendations
            vm_recommendations = self._get_vm_optimization_recommendations()
            recommendations.extend(vm_recommendations)
            
            # Get storage optimization recommendations
            storage_recommendations = self._get_storage_optimization_recommendations()
            recommendations.extend(storage_recommendations)
            
            # Get unused resource recommendations
            unused_recommendations = self._get_unused_resource_recommendations()
            recommendations.extend(unused_recommendations)
            
            logger.info(f"Generated {len(recommendations)} optimization recommendations")
            return recommendations
            
        except Exception as e:
            logger.error(f"Error getting optimization recommendations: {e}")
            return []
    
    def _get_vm_optimization_recommendations(self) -> List[Dict]:
        """Get VM rightsizing recommendations"""
        recommendations = []
        
        try:
            # Get all VMs
            vms = list(self.compute_client.virtual_machines.list_all())
            
            for vm in vms:
                # Get VM metrics
                metrics = self._get_vm_metrics(vm.name, vm.id.split('/')[4])  # Resource group name
                
                if metrics:
                    cpu_avg = metrics.get("cpu_average", 0)
                    memory_avg = metrics.get("memory_average", 0)
                    
                    # Check for underutilized VMs
                    cpu_threshold = self.config["thresholds"]["cpu_utilization_threshold"]
                    memory_threshold = self.config["thresholds"]["memory_utilization_threshold"]
                    
                    if cpu_avg < cpu_threshold and memory_avg < memory_threshold:
                        recommendations.append({
                            "type": "vm_rightsizing",
                            "resource_name": vm.name,
                            "resource_id": vm.id,
                            "current_size": vm.hardware_profile.vm_size,
                            "cpu_utilization": cpu_avg,
                            "memory_utilization": memory_avg,
                            "recommendation": "Downsize VM",
                            "potential_savings": self._calculate_vm_savings(vm.hardware_profile.vm_size),
                            "severity": "medium"
                        })
            
            return recommendations
            
        except Exception as e:
            logger.error(f"Error getting VM recommendations: {e}")
            return []
    
    def _get_vm_metrics(self, vm_name: str, resource_group: str) -> Dict:
        """Get VM performance metrics"""
        try:
            end_time = datetime.utcnow()
            start_time = end_time - timedelta(days=7)
            
            # Get CPU metrics
            cpu_metrics = self.monitor_client.metrics.list(
                resource_uri=f"/subscriptions/{self.subscription_id}/resourceGroups/{resource_group}/providers/Microsoft.Compute/virtualMachines/{vm_name}",
                timespan=f"{start_time.isoformat()}/{end_time.isoformat()}",
                interval="PT1H",
                metricnames="Percentage CPU",
                aggregation="Average"
            )
            
            cpu_values = []
            for metric in cpu_metrics.value:
                for timeseries in metric.timeseries:
                    for data in timeseries.data:
                        if data.average is not None:
                            cpu_values.append(data.average)
            
            cpu_average = sum(cpu_values) / len(cpu_values) if cpu_values else 0
            
            # Note: Memory metrics require guest OS diagnostics
            # For simplicity, using CPU as primary indicator
            return {
                "cpu_average": cpu_average,
                "memory_average": 50  # Placeholder - requires guest diagnostics
            }
            
        except Exception as e:
            logger.error(f"Error getting VM metrics for {vm_name}: {e}")
            return {}
    
    def _calculate_vm_savings(self, vm_size: str) -> float:
        """Calculate potential savings from VM rightsizing"""
        # Simplified savings calculation
        # In practice, this would use Azure pricing APIs
        size_costs = {
            "Standard_D2s_v3": 70.08,  # Monthly cost in USD
            "Standard_D4s_v3": 140.16,
            "Standard_D8s_v3": 280.32,
            "Standard_B1s": 7.59,
            "Standard_B2s": 30.37
        }
        
        current_cost = size_costs.get(vm_size, 100)
        # Assume 30% savings from rightsizing
        return current_cost * 0.3
    
    def _get_storage_optimization_recommendations(self) -> List[Dict]:
        """Get storage optimization recommendations"""
        recommendations = []
        
        try:
            # Get storage accounts
            storage_accounts = list(self.resource_client.resources.list(
                filter="resourceType eq 'Microsoft.Storage/storageAccounts'"
            ))
            
            for storage in storage_accounts:
                # Check for optimization opportunities
                recommendations.append({
                    "type": "storage_optimization",
                    "resource_name": storage.name,
                    "resource_id": storage.id,
                    "recommendation": "Implement lifecycle management",
                    "potential_savings": 25.0,  # Percentage
                    "severity": "low"
                })
            
            return recommendations
            
        except Exception as e:
            logger.error(f"Error getting storage recommendations: {e}")
            return []
    
    def _get_unused_resource_recommendations(self) -> List[Dict]:
        """Get unused resource recommendations"""
        recommendations = []
        
        try:
            # Find unattached disks
            disks = list(self.compute_client.disks.list())
            
            for disk in disks:
                if not disk.managed_by:  # Unattached disk
                    recommendations.append({
                        "type": "unused_resource",
                        "resource_name": disk.name,
                        "resource_id": disk.id,
                        "resource_type": "Managed Disk",
                        "recommendation": "Delete unused disk",
                        "potential_savings": 10.0,  # Monthly cost
                        "severity": "medium"
                    })
            
            return recommendations
            
        except Exception as e:
            logger.error(f"Error getting unused resource recommendations: {e}")
            return []
    
    def send_notifications(self, anomalies: List[Dict], recommendations: List[Dict]):
        """
        Send notifications for anomalies and recommendations
        
        Args:
            anomalies: List of detected anomalies
            recommendations: List of optimization recommendations
        """
        try:
            # Prepare notification content
            content = self._prepare_notification_content(anomalies, recommendations)
            
            # Send email notification
            if self.config["notifications"]["email"]:
                self._send_email_notification(content)
            
            # Send Slack notification
            if self.config["notifications"]["slack_webhook"]:
                self._send_slack_notification(content)
            
            # Create ServiceNow incident
            if self.config["notifications"]["servicenow_enabled"]:
                self._create_servicenow_incident(content)
            
            logger.info("Notifications sent successfully")
            
        except Exception as e:
            logger.error(f"Error sending notifications: {e}")
    
    def _prepare_notification_content(self, anomalies: List[Dict], recommendations: List[Dict]) -> Dict:
        """Prepare notification content"""
        high_severity_anomalies = [a for a in anomalies if a.get("severity") == "high"]
        total_potential_savings = sum(r.get("potential_savings", 0) for r in recommendations)
        
        return {
            "summary": f"Azure Cost Monitor Alert - {len(anomalies)} anomalies, {len(recommendations)} recommendations",
            "anomalies_count": len(anomalies),
            "high_severity_anomalies": len(high_severity_anomalies),
            "recommendations_count": len(recommendations),
            "potential_savings": total_potential_savings,
            "anomalies": anomalies[:5],  # Top 5 anomalies
            "recommendations": recommendations[:10]  # Top 10 recommendations
        }
    
    def _send_slack_notification(self, content: Dict):
        """Send Slack notification"""
        webhook_url = self.config["notifications"]["slack_webhook"]
        if not webhook_url:
            return
        
        message = {
            "text": content["summary"],
            "attachments": [
                {
                    "color": "danger" if content["high_severity_anomalies"] > 0 else "warning",
                    "fields": [
                        {
                            "title": "Anomalies Detected",
                            "value": str(content["anomalies_count"]),
                            "short": True
                        },
                        {
                            "title": "Optimization Opportunities",
                            "value": str(content["recommendations_count"]),
                            "short": True
                        },
                        {
                            "title": "Potential Monthly Savings",
                            "value": f"${content['potential_savings']:.2f}",
                            "short": True
                        }
                    ]
                }
            ]
        }
        
        response = requests.post(webhook_url, json=message)
        response.raise_for_status()
    
    def _create_servicenow_incident(self, content: Dict):
        """Create ServiceNow incident for high-severity issues"""
        if not self.config["servicenow"]["instance_url"]:
            return
        
        # Only create incidents for high-severity anomalies
        if content["high_severity_anomalies"] == 0:
            return
        
        incident_data = {
            "short_description": f"Azure Cost Anomaly Detected - {content['high_severity_anomalies']} high-severity issues",
            "description": f"Azure Cost Monitor detected {content['anomalies_count']} cost anomalies and {content['recommendations_count']} optimization opportunities. Potential monthly savings: ${content['potential_savings']:.2f}",
            "category": "Cloud Services",
            "subcategory": "Cost Management",
            "priority": "2",
            "assignment_group": "Cloud Operations"
        }
        
        # ServiceNow API call
        url = f"{self.config['servicenow']['instance_url']}/api/now/table/{self.config['servicenow']['table_name']}"
        auth = (self.config["servicenow"]["username"], self.config["servicenow"]["password"])
        headers = {"Content-Type": "application/json", "Accept": "application/json"}
        
        response = requests.post(url, auth=auth, headers=headers, json=incident_data)
        response.raise_for_status()
        
        logger.info(f"Created ServiceNow incident: {response.json()['result']['number']}")
    
    def run_monitoring_cycle(self):
        """Run complete monitoring cycle"""
        logger.info("Starting Azure cost monitoring cycle")
        
        try:
            # Get current cost data
            cost_data = self.get_current_costs(days=30)
            if not cost_data:
                logger.error("Failed to retrieve cost data")
                return
            
            # Detect anomalies
            anomalies = self.detect_cost_anomalies(cost_data)
            
            # Get optimization recommendations
            recommendations = self.get_optimization_recommendations()
            
            # Send notifications
            if anomalies or recommendations:
                self.send_notifications(anomalies, recommendations)
            
            # Log summary
            logger.info(f"Monitoring cycle completed: {len(anomalies)} anomalies, {len(recommendations)} recommendations")
            
            # Return results for further processing
            return {
                "cost_data": cost_data,
                "anomalies": anomalies,
                "recommendations": recommendations,
                "timestamp": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error in monitoring cycle: {e}")
            return None

def main():
    """Main function"""
    import argparse
    
    parser = argparse.ArgumentParser(description="Azure Cost Monitor")
    parser.add_argument("--subscription-id", required=True, help="Azure subscription ID")
    parser.add_argument("--config", default="config/monitor_config.json", help="Configuration file path")
    parser.add_argument("--output", help="Output file for results")
    
    args = parser.parse_args()
    
    # Initialize monitor
    monitor = AzureCostMonitor(args.subscription_id, args.config)
    
    # Run monitoring cycle
    results = monitor.run_monitoring_cycle()
    
    # Save results if output file specified
    if args.output and results:
        with open(args.output, 'w') as f:
            json.dump(results, f, indent=2, default=str)
        logger.info(f"Results saved to {args.output}")

if __name__ == "__main__":
    main()

