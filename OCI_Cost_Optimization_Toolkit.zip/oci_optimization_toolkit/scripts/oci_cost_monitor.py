#!/usr/bin/env python3
"""
Oracle Cloud Infrastructure (OCI) Cost Monitor
Comprehensive cost monitoring and optimization automation for OCI

This script provides real-time cost monitoring, anomaly detection, and automated
optimization recommendations for OCI environments, leveraging OCI's unique features
including Universal Credits, no egress fees, and flexible compute shapes.

Features:
- Real-time cost monitoring across compartments
- Universal Credits utilization tracking
- Automated optimization recommendations
- ServiceNow integration for workflow automation
- Flexible compute shape optimization
- Preemptible instance management
- Storage tier optimization
- Autonomous Database monitoring

Author: CloudCostChefs
Version: 1.0
"""

import oci
import json
import logging
import datetime
import requests
import pandas as pd
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from concurrent.futures import ThreadPoolExecutor, as_completed
import time
import os
import sys

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('oci_cost_monitor.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

@dataclass
class OCICostAlert:
    """Data class for OCI cost alerts"""
    alert_type: str
    severity: str
    compartment_id: str
    compartment_name: str
    resource_id: str
    resource_type: str
    current_cost: float
    expected_cost: float
    variance_percentage: float
    recommendation: str
    potential_savings: float
    timestamp: datetime.datetime

@dataclass
class OCIOptimizationRecommendation:
    """Data class for OCI optimization recommendations"""
    resource_id: str
    resource_type: str
    compartment_id: str
    current_configuration: Dict
    recommended_configuration: Dict
    estimated_savings: float
    confidence_score: float
    implementation_effort: str
    oci_specific_feature: str  # Universal Credits, Flexible Shapes, etc.

class OCICreditsManager:
    """Manages OCI Universal Credits monitoring and optimization"""
    
    def __init__(self, config: oci.config):
        self.config = config
        self.billing_client = oci.billing.BillingClient(config)
        self.usage_api_client = oci.usage_api.UsageapiClient(config)
        
    def get_universal_credits_utilization(self, tenancy_id: str) -> Dict:
        """Get Universal Credits utilization and allocation"""
        try:
            # Get current credit balance and utilization
            credits_response = self.billing_client.list_billing_schedules(
                compartment_id=tenancy_id,
                billing_schedule_state="ACTIVE"
            )
            
            # Calculate credit utilization metrics
            total_credits = 0
            used_credits = 0
            
            for schedule in credits_response.data:
                if hasattr(schedule, 'amount'):
                    total_credits += float(schedule.amount)
                if hasattr(schedule, 'used_amount'):
                    used_credits += float(schedule.used_amount)
            
            utilization_percentage = (used_credits / total_credits * 100) if total_credits > 0 else 0
            
            return {
                'total_credits': total_credits,
                'used_credits': used_credits,
                'remaining_credits': total_credits - used_credits,
                'utilization_percentage': utilization_percentage,
                'optimization_opportunity': self._assess_credit_optimization(utilization_percentage)
            }
            
        except Exception as e:
            logger.error(f"Error getting Universal Credits utilization: {str(e)}")
            return {}
    
    def _assess_credit_optimization(self, utilization_percentage: float) -> Dict:
        """Assess Universal Credits optimization opportunities"""
        if utilization_percentage < 70:
            return {
                'status': 'underutilized',
                'recommendation': 'Consider reallocating credits or adjusting spending patterns',
                'action': 'optimize_allocation'
            }
        elif utilization_percentage > 95:
            return {
                'status': 'overutilized',
                'recommendation': 'Monitor for potential overspend and consider additional credits',
                'action': 'monitor_closely'
            }
        else:
            return {
                'status': 'optimal',
                'recommendation': 'Credit utilization is within optimal range',
                'action': 'maintain'
            }

class OCIFlexibleShapeOptimizer:
    """Optimizes OCI Flexible Compute Shapes for cost efficiency"""
    
    def __init__(self, config: oci.config):
        self.config = config
        self.compute_client = oci.core.ComputeClient(config)
        self.monitoring_client = oci.monitoring.MonitoringClient(config)
        
    def analyze_flexible_shape_opportunities(self, compartment_id: str) -> List[OCIOptimizationRecommendation]:
        """Analyze opportunities for flexible compute shape optimization"""
        recommendations = []
        
        try:
            # Get all compute instances in compartment
            instances = self.compute_client.list_instances(
                compartment_id=compartment_id,
                lifecycle_state="RUNNING"
            ).data
            
            for instance in instances:
                if self._is_flexible_shape_candidate(instance):
                    recommendation = self._generate_flexible_shape_recommendation(instance)
                    if recommendation:
                        recommendations.append(recommendation)
                        
        except Exception as e:
            logger.error(f"Error analyzing flexible shape opportunities: {str(e)}")
            
        return recommendations
    
    def _is_flexible_shape_candidate(self, instance) -> bool:
        """Check if instance is a candidate for flexible shape optimization"""
        # Check if instance is already using flexible shapes
        flexible_shapes = ['VM.Standard3.Flex', 'VM.Standard.E4.Flex', 'VM.Optimized3.Flex']
        return instance.shape not in flexible_shapes
    
    def _generate_flexible_shape_recommendation(self, instance) -> Optional[OCIOptimizationRecommendation]:
        """Generate flexible shape optimization recommendation"""
        try:
            # Get instance utilization metrics
            utilization = self._get_instance_utilization(instance.id)
            
            if utilization['cpu_avg'] < 50 or utilization['memory_avg'] < 60:
                # Calculate optimal flexible shape configuration
                optimal_config = self._calculate_optimal_flexible_config(instance, utilization)
                
                return OCIOptimizationRecommendation(
                    resource_id=instance.id,
                    resource_type="compute_instance",
                    compartment_id=instance.compartment_id,
                    current_configuration={
                        'shape': instance.shape,
                        'ocpus': getattr(instance.shape_config, 'ocpus', 'N/A'),
                        'memory_gb': getattr(instance.shape_config, 'memory_in_gbs', 'N/A')
                    },
                    recommended_configuration=optimal_config,
                    estimated_savings=optimal_config.get('estimated_savings', 0),
                    confidence_score=0.85,
                    implementation_effort="Medium",
                    oci_specific_feature="Flexible Compute Shapes"
                )
                
        except Exception as e:
            logger.error(f"Error generating flexible shape recommendation: {str(e)}")
            
        return None
    
    def _get_instance_utilization(self, instance_id: str) -> Dict:
        """Get instance CPU and memory utilization metrics"""
        try:
            end_time = datetime.datetime.now()
            start_time = end_time - datetime.timedelta(days=7)
            
            # Query CPU utilization
            cpu_query = f"""
            CpuUtilization[1m].mean()
            {{ resourceId = "{instance_id}" }}
            """
            
            cpu_response = self.monitoring_client.summarize_metrics_data(
                compartment_id=self.config['compartment'],
                summarize_metrics_data_details=oci.monitoring.models.SummarizeMetricsDataDetails(
                    namespace="oci_computeagent",
                    query=cpu_query,
                    start_time=start_time,
                    end_time=end_time,
                    resolution="1h"
                )
            )
            
            # Calculate average utilization
            cpu_values = []
            for metric in cpu_response.data:
                for datapoint in metric.aggregated_datapoints:
                    if datapoint.value:
                        cpu_values.append(datapoint.value)
            
            cpu_avg = sum(cpu_values) / len(cpu_values) if cpu_values else 0
            
            return {
                'cpu_avg': cpu_avg,
                'memory_avg': 70,  # Placeholder - OCI doesn't provide memory metrics by default
                'cpu_max': max(cpu_values) if cpu_values else 0,
                'cpu_min': min(cpu_values) if cpu_values else 0
            }
            
        except Exception as e:
            logger.error(f"Error getting instance utilization: {str(e)}")
            return {'cpu_avg': 50, 'memory_avg': 50, 'cpu_max': 100, 'cpu_min': 0}
    
    def _calculate_optimal_flexible_config(self, instance, utilization: Dict) -> Dict:
        """Calculate optimal flexible shape configuration"""
        # Get current shape details
        current_ocpus = getattr(instance.shape_config, 'ocpus', 2)
        current_memory = getattr(instance.shape_config, 'memory_in_gbs', 16)
        
        # Calculate optimal configuration based on utilization
        optimal_ocpus = max(1, int(current_ocpus * (utilization['cpu_avg'] / 100) * 1.2))
        optimal_memory = max(1, int(current_memory * (utilization['memory_avg'] / 100) * 1.2))
        
        # Estimate cost savings (approximate)
        current_cost = self._estimate_shape_cost(instance.shape, current_ocpus, current_memory)
        optimal_cost = self._estimate_flexible_shape_cost(optimal_ocpus, optimal_memory)
        estimated_savings = max(0, current_cost - optimal_cost)
        
        return {
            'shape': 'VM.Standard3.Flex',
            'ocpus': optimal_ocpus,
            'memory_gb': optimal_memory,
            'estimated_monthly_cost': optimal_cost,
            'estimated_savings': estimated_savings
        }
    
    def _estimate_shape_cost(self, shape: str, ocpus: int, memory_gb: int) -> float:
        """Estimate monthly cost for current shape"""
        # Simplified cost estimation - replace with actual OCI pricing API
        base_costs = {
            'VM.Standard2.1': 73.0,
            'VM.Standard2.2': 146.0,
            'VM.Standard2.4': 292.0,
            'VM.Standard2.8': 584.0,
            'VM.Standard3.1': 65.0,
            'VM.Standard3.2': 130.0,
            'VM.Standard3.4': 260.0,
            'VM.Standard3.8': 520.0
        }
        return base_costs.get(shape, ocpus * 32.5)  # Default rate per OCPU
    
    def _estimate_flexible_shape_cost(self, ocpus: int, memory_gb: int) -> float:
        """Estimate monthly cost for flexible shape"""
        # OCI Flexible shape pricing (approximate)
        ocpu_cost = ocpus * 32.5  # Per OCPU per month
        memory_cost = memory_gb * 2.0  # Per GB per month
        return ocpu_cost + memory_cost

class OCIStorageTierOptimizer:
    """Optimizes OCI Object Storage tier placement for cost efficiency"""
    
    def __init__(self, config: oci.config):
        self.config = config
        self.object_storage_client = oci.object_storage.ObjectStorageClient(config)
        
    def analyze_storage_tier_opportunities(self, compartment_id: str) -> List[OCIOptimizationRecommendation]:
        """Analyze Object Storage tier optimization opportunities"""
        recommendations = []
        
        try:
            # Get namespace
            namespace = self.object_storage_client.get_namespace().data
            
            # List all buckets in compartment
            buckets = self.object_storage_client.list_buckets(
                namespace_name=namespace,
                compartment_id=compartment_id
            ).data
            
            for bucket in buckets:
                bucket_recommendations = self._analyze_bucket_tier_optimization(
                    namespace, bucket.name, compartment_id
                )
                recommendations.extend(bucket_recommendations)
                
        except Exception as e:
            logger.error(f"Error analyzing storage tier opportunities: {str(e)}")
            
        return recommendations
    
    def _analyze_bucket_tier_optimization(self, namespace: str, bucket_name: str, compartment_id: str) -> List[OCIOptimizationRecommendation]:
        """Analyze tier optimization for a specific bucket"""
        recommendations = []
        
        try:
            # Get bucket details
            bucket = self.object_storage_client.get_bucket(
                namespace_name=namespace,
                bucket_name=bucket_name
            ).data
            
            # List objects in bucket (sample for analysis)
            objects = self.object_storage_client.list_objects(
                namespace_name=namespace,
                bucket_name=bucket_name,
                limit=1000
            ).data.objects
            
            # Analyze objects for tier optimization
            for obj in objects:
                recommendation = self._generate_object_tier_recommendation(
                    namespace, bucket_name, obj, compartment_id
                )
                if recommendation:
                    recommendations.append(recommendation)
                    
        except Exception as e:
            logger.error(f"Error analyzing bucket {bucket_name}: {str(e)}")
            
        return recommendations
    
    def _generate_object_tier_recommendation(self, namespace: str, bucket_name: str, obj, compartment_id: str) -> Optional[OCIOptimizationRecommendation]:
        """Generate tier optimization recommendation for an object"""
        try:
            # Calculate object age
            age_days = (datetime.datetime.now() - obj.time_created.replace(tzinfo=None)).days
            
            # Get object size in GB
            size_gb = obj.size / (1024**3)
            
            # Determine optimal tier based on age and access patterns
            current_tier = getattr(obj, 'storage_tier', 'Standard')
            recommended_tier = self._determine_optimal_tier(age_days, size_gb, current_tier)
            
            if recommended_tier != current_tier:
                savings = self._calculate_tier_savings(size_gb, current_tier, recommended_tier)
                
                return OCIOptimizationRecommendation(
                    resource_id=f"{namespace}/{bucket_name}/{obj.name}",
                    resource_type="object_storage",
                    compartment_id=compartment_id,
                    current_configuration={
                        'tier': current_tier,
                        'size_gb': size_gb,
                        'age_days': age_days
                    },
                    recommended_configuration={
                        'tier': recommended_tier,
                        'size_gb': size_gb,
                        'estimated_monthly_cost': self._calculate_tier_cost(size_gb, recommended_tier)
                    },
                    estimated_savings=savings,
                    confidence_score=0.9,
                    implementation_effort="Low",
                    oci_specific_feature="Object Storage Tiers"
                )
                
        except Exception as e:
            logger.error(f"Error generating object tier recommendation: {str(e)}")
            
        return None
    
    def _determine_optimal_tier(self, age_days: int, size_gb: float, current_tier: str) -> str:
        """Determine optimal storage tier based on age and access patterns"""
        if age_days > 365:
            return "Archive"
        elif age_days > 30:
            return "InfrequentAccess"
        else:
            return "Standard"
    
    def _calculate_tier_cost(self, size_gb: float, tier: str) -> float:
        """Calculate monthly cost for storage tier"""
        tier_costs = {
            'Standard': 0.0255,  # per GB per month
            'InfrequentAccess': 0.01,  # per GB per month
            'Archive': 0.0017  # per GB per month
        }
        return size_gb * tier_costs.get(tier, 0.0255)
    
    def _calculate_tier_savings(self, size_gb: float, current_tier: str, recommended_tier: str) -> float:
        """Calculate monthly savings from tier optimization"""
        current_cost = self._calculate_tier_cost(size_gb, current_tier)
        recommended_cost = self._calculate_tier_cost(size_gb, recommended_tier)
        return max(0, current_cost - recommended_cost)

class OCICostMonitor:
    """Main OCI Cost Monitor class"""
    
    def __init__(self, config_file: str = "config/oci_config.json"):
        self.config = self._load_config(config_file)
        self.oci_config = oci.config.from_file()
        
        # Initialize OCI clients
        self.identity_client = oci.identity.IdentityClient(self.oci_config)
        self.usage_api_client = oci.usage_api.UsageapiClient(self.oci_config)
        self.monitoring_client = oci.monitoring.MonitoringClient(self.oci_config)
        
        # Initialize specialized optimizers
        self.credits_manager = OCICreditsManager(self.oci_config)
        self.shape_optimizer = OCIFlexibleShapeOptimizer(self.oci_config)
        self.storage_optimizer = OCIStorageTierOptimizer(self.oci_config)
        
        # Initialize alerts and recommendations lists
        self.alerts: List[OCICostAlert] = []
        self.recommendations: List[OCIOptimizationRecommendation] = []
        
    def _load_config(self, config_file: str) -> Dict:
        """Load configuration from JSON file"""
        try:
            with open(config_file, 'r') as f:
                return json.load(f)
        except FileNotFoundError:
            logger.warning(f"Config file {config_file} not found, using defaults")
            return self._get_default_config()
    
    def _get_default_config(self) -> Dict:
        """Get default configuration"""
        return {
            "tenancy_id": os.getenv("OCI_TENANCY_ID"),
            "compartment_id": os.getenv("OCI_COMPARTMENT_ID"),
            "region": "us-ashburn-1",
            "monitoring": {
                "cost_threshold_percentage": 20,
                "utilization_threshold": 80,
                "alert_email": "finops@company.com"
            },
            "universal_credits": {
                "monthly_budget": 10000,
                "alert_thresholds": [50, 80, 95]
            },
            "servicenow": {
                "enabled": False,
                "instance_url": "",
                "username": "",
                "password": ""
            }
        }
    
    def run_cost_monitoring(self) -> Dict:
        """Run comprehensive OCI cost monitoring"""
        logger.info("Starting OCI cost monitoring...")
        
        results = {
            'timestamp': datetime.datetime.now().isoformat(),
            'tenancy_id': self.config.get('tenancy_id'),
            'alerts': [],
            'recommendations': [],
            'universal_credits': {},
            'summary': {}
        }
        
        try:
            # Monitor Universal Credits
            logger.info("Monitoring Universal Credits utilization...")
            credits_data = self.credits_manager.get_universal_credits_utilization(
                self.config['tenancy_id']
            )
            results['universal_credits'] = credits_data
            
            # Get compartments for monitoring
            compartments = self._get_compartments()
            
            # Monitor each compartment
            for compartment in compartments:
                logger.info(f"Monitoring compartment: {compartment.name}")
                
                # Generate cost alerts
                compartment_alerts = self._generate_cost_alerts(compartment)
                results['alerts'].extend(compartment_alerts)
                
                # Generate optimization recommendations
                shape_recommendations = self.shape_optimizer.analyze_flexible_shape_opportunities(
                    compartment.id
                )
                storage_recommendations = self.storage_optimizer.analyze_storage_tier_opportunities(
                    compartment.id
                )
                
                results['recommendations'].extend(shape_recommendations)
                results['recommendations'].extend(storage_recommendations)
            
            # Generate summary
            results['summary'] = self._generate_monitoring_summary(results)
            
            # Send notifications
            self._send_notifications(results)
            
            logger.info("OCI cost monitoring completed successfully")
            
        except Exception as e:
            logger.error(f"Error during cost monitoring: {str(e)}")
            results['error'] = str(e)
        
        return results
    
    def _get_compartments(self) -> List:
        """Get list of compartments to monitor"""
        try:
            compartments = self.identity_client.list_compartments(
                compartment_id=self.config['tenancy_id'],
                lifecycle_state="ACTIVE"
            ).data
            
            # Add root compartment
            root_compartment = self.identity_client.get_compartment(
                compartment_id=self.config['tenancy_id']
            ).data
            compartments.append(root_compartment)
            
            return compartments
            
        except Exception as e:
            logger.error(f"Error getting compartments: {str(e)}")
            return []
    
    def _generate_cost_alerts(self, compartment) -> List[OCICostAlert]:
        """Generate cost alerts for a compartment"""
        alerts = []
        
        try:
            # Get cost data for the compartment
            end_time = datetime.datetime.now()
            start_time = end_time - datetime.timedelta(days=30)
            
            # This is a simplified example - replace with actual OCI Usage API calls
            current_cost = self._get_compartment_cost(compartment.id, start_time, end_time)
            expected_cost = self._get_expected_cost(compartment.id)
            
            if current_cost > expected_cost * 1.2:  # 20% threshold
                alert = OCICostAlert(
                    alert_type="cost_anomaly",
                    severity="high",
                    compartment_id=compartment.id,
                    compartment_name=compartment.name,
                    resource_id=compartment.id,
                    resource_type="compartment",
                    current_cost=current_cost,
                    expected_cost=expected_cost,
                    variance_percentage=((current_cost - expected_cost) / expected_cost) * 100,
                    recommendation="Review resource usage and implement cost optimization",
                    potential_savings=current_cost - expected_cost,
                    timestamp=datetime.datetime.now()
                )
                alerts.append(alert)
                
        except Exception as e:
            logger.error(f"Error generating cost alerts for compartment {compartment.name}: {str(e)}")
        
        return alerts
    
    def _get_compartment_cost(self, compartment_id: str, start_time: datetime.datetime, end_time: datetime.datetime) -> float:
        """Get actual cost for a compartment (simplified)"""
        # This is a placeholder - implement actual OCI Usage API call
        return 1500.0  # Example cost
    
    def _get_expected_cost(self, compartment_id: str) -> float:
        """Get expected cost for a compartment (simplified)"""
        # This is a placeholder - implement actual budget/forecast logic
        return 1200.0  # Example expected cost
    
    def _generate_monitoring_summary(self, results: Dict) -> Dict:
        """Generate monitoring summary"""
        total_alerts = len(results['alerts'])
        total_recommendations = len(results['recommendations'])
        
        # Calculate potential savings
        total_potential_savings = sum(
            rec.estimated_savings for rec in results['recommendations']
        )
        
        # Universal Credits summary
        credits_data = results.get('universal_credits', {})
        credits_utilization = credits_data.get('utilization_percentage', 0)
        
        return {
            'total_alerts': total_alerts,
            'high_severity_alerts': len([a for a in results['alerts'] if a.severity == 'high']),
            'total_recommendations': total_recommendations,
            'total_potential_savings': total_potential_savings,
            'universal_credits_utilization': credits_utilization,
            'optimization_opportunities': {
                'flexible_shapes': len([r for r in results['recommendations'] if r.oci_specific_feature == 'Flexible Compute Shapes']),
                'storage_tiers': len([r for r in results['recommendations'] if r.oci_specific_feature == 'Object Storage Tiers'])
            }
        }
    
    def _send_notifications(self, results: Dict):
        """Send notifications for alerts and recommendations"""
        try:
            # Email notifications
            if self.config.get('monitoring', {}).get('alert_email'):
                self._send_email_notification(results)
            
            # ServiceNow integration
            if self.config.get('servicenow', {}).get('enabled'):
                self._create_servicenow_tickets(results)
                
        except Exception as e:
            logger.error(f"Error sending notifications: {str(e)}")
    
    def _send_email_notification(self, results: Dict):
        """Send email notification (placeholder)"""
        logger.info("Email notification would be sent here")
        # Implement actual email sending logic
    
    def _create_servicenow_tickets(self, results: Dict):
        """Create ServiceNow tickets for high-priority alerts"""
        logger.info("ServiceNow tickets would be created here")
        # Implement actual ServiceNow integration

def main():
    """Main function"""
    try:
        # Initialize OCI Cost Monitor
        monitor = OCICostMonitor()
        
        # Run cost monitoring
        results = monitor.run_cost_monitoring()
        
        # Output results
        print(json.dumps(results, indent=2, default=str))
        
        # Save results to file
        with open(f"oci_cost_monitoring_results_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.json", 'w') as f:
            json.dump(results, f, indent=2, default=str)
            
    except Exception as e:
        logger.error(f"Error in main: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()

