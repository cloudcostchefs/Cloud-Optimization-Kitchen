#!/usr/bin/env python3
"""
Google Cloud Platform Cost Monitoring and Optimization Script

This script provides comprehensive cost monitoring, analysis, and optimization
for GCP environments. It includes real-time cost tracking, anomaly detection,
budget monitoring, and automated optimization recommendations.

Features:
- Real-time billing data analysis
- Sustained use discount tracking
- Committed use discount monitoring
- BigQuery cost optimization
- Storage lifecycle optimization
- Automated alerting and reporting

Author: CloudCostChefs
Version: 1.0
License: MIT
"""

import json
import logging
import argparse
import datetime
import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from google.cloud import billing_v1
from google.cloud import bigquery
from google.cloud import monitoring_v3
from google.cloud import storage
from google.cloud import compute_v1
from google.oauth2 import service_account
import smtplib
import requests
from email.mime.text import MimeText
from email.mime.multipart import MimeMultipart

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('gcp_cost_monitor.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

@dataclass
class CostAlert:
    """Data class for cost alerts"""
    alert_type: str
    severity: str
    project_id: str
    service: str
    current_cost: float
    threshold: float
    message: str
    timestamp: datetime.datetime

@dataclass
class OptimizationRecommendation:
    """Data class for optimization recommendations"""
    resource_type: str
    resource_id: str
    project_id: str
    recommendation_type: str
    potential_savings: float
    confidence: float
    description: str
    implementation_effort: str

class GCPCostMonitor:
    """Main class for GCP cost monitoring and optimization"""
    
    def __init__(self, config_file: str = 'config/gcp_monitoring_config.json'):
        """Initialize the GCP Cost Monitor"""
        self.config = self._load_config(config_file)
        self.billing_client = billing_v1.CloudBillingClient()
        self.bigquery_client = bigquery.Client()
        self.monitoring_client = monitoring_v3.MetricServiceClient()
        self.storage_client = storage.Client()
        self.compute_client = compute_v1.InstancesClient()
        
        # Initialize cost tracking
        self.cost_alerts = []
        self.optimization_recommendations = []
        
        logger.info("GCP Cost Monitor initialized successfully")
    
    def _load_config(self, config_file: str) -> Dict:
        """Load configuration from JSON file"""
        try:
            with open(config_file, 'r') as f:
                config = json.load(f)
            logger.info(f"Configuration loaded from {config_file}")
            return config
        except FileNotFoundError:
            logger.error(f"Configuration file {config_file} not found")
            raise
        except json.JSONDecodeError as e:
            logger.error(f"Invalid JSON in configuration file: {e}")
            raise
    
    def get_billing_data(self, days: int = 30) -> pd.DataFrame:
        """Retrieve billing data from BigQuery"""
        try:
            end_date = datetime.datetime.now()
            start_date = end_date - datetime.timedelta(days=days)
            
            query = f"""
            SELECT
                service.description as service_name,
                project.id as project_id,
                location.location as location,
                cost,
                currency,
                usage_start_time,
                usage_end_time,
                credits,
                labels
            FROM `{self.config['billing_export_table']}`
            WHERE usage_start_time >= '{start_date.strftime('%Y-%m-%d')}'
                AND usage_end_time <= '{end_date.strftime('%Y-%m-%d')}'
                AND cost > 0
            ORDER BY usage_start_time DESC
            """
            
            df = self.bigquery_client.query(query).to_dataframe()
            logger.info(f"Retrieved {len(df)} billing records")
            return df
            
        except Exception as e:
            logger.error(f"Error retrieving billing data: {e}")
            raise
    
    def analyze_cost_trends(self, billing_data: pd.DataFrame) -> Dict:
        """Analyze cost trends and identify anomalies"""
        try:
            # Convert usage_start_time to datetime
            billing_data['date'] = pd.to_datetime(billing_data['usage_start_time']).dt.date
            
            # Daily cost aggregation
            daily_costs = billing_data.groupby('date')['cost'].sum().reset_index()
            daily_costs = daily_costs.sort_values('date')
            
            # Calculate moving averages
            daily_costs['ma_7'] = daily_costs['cost'].rolling(window=7).mean()
            daily_costs['ma_30'] = daily_costs['cost'].rolling(window=30).mean()
            
            # Detect anomalies (cost > 2 standard deviations from mean)
            mean_cost = daily_costs['cost'].mean()
            std_cost = daily_costs['cost'].std()
            threshold = mean_cost + (2 * std_cost)
            
            anomalies = daily_costs[daily_costs['cost'] > threshold]
            
            # Service-level analysis
            service_costs = billing_data.groupby('service_name')['cost'].sum().sort_values(ascending=False)
            
            # Project-level analysis
            project_costs = billing_data.groupby('project_id')['cost'].sum().sort_values(ascending=False)
            
            analysis = {
                'total_cost': billing_data['cost'].sum(),
                'daily_average': daily_costs['cost'].mean(),
                'cost_trend': 'increasing' if daily_costs['cost'].iloc[-1] > daily_costs['ma_7'].iloc[-1] else 'decreasing',
                'anomalies': len(anomalies),
                'top_services': service_costs.head(10).to_dict(),
                'top_projects': project_costs.head(10).to_dict(),
                'anomaly_dates': anomalies['date'].tolist()
            }
            
            logger.info(f"Cost trend analysis completed. Total cost: ${analysis['total_cost']:.2f}")
            return analysis
            
        except Exception as e:
            logger.error(f"Error analyzing cost trends: {e}")
            raise
    
    def check_budget_alerts(self, billing_data: pd.DataFrame) -> List[CostAlert]:
        """Check for budget threshold violations"""
        alerts = []
        
        try:
            # Get current month costs by project
            current_month = datetime.datetime.now().replace(day=1)
            monthly_data = billing_data[
                pd.to_datetime(billing_data['usage_start_time']) >= current_month
            ]
            
            project_costs = monthly_data.groupby('project_id')['cost'].sum()
            
            for project_id, current_cost in project_costs.items():
                # Get budget configuration for project
                budget_config = self.config.get('project_budgets', {}).get(project_id)
                if not budget_config:
                    continue
                
                monthly_budget = budget_config['monthly_budget']
                alert_thresholds = budget_config['alert_thresholds']
                
                for threshold_pct in alert_thresholds:
                    threshold_amount = monthly_budget * (threshold_pct / 100)
                    
                    if current_cost >= threshold_amount:
                        severity = 'high' if threshold_pct >= 90 else 'medium' if threshold_pct >= 80 else 'low'
                        
                        alert = CostAlert(
                            alert_type='budget_threshold',
                            severity=severity,
                            project_id=project_id,
                            service='all',
                            current_cost=current_cost,
                            threshold=threshold_amount,
                            message=f"Project {project_id} has exceeded {threshold_pct}% of monthly budget",
                            timestamp=datetime.datetime.now()
                        )
                        alerts.append(alert)
                        
            logger.info(f"Generated {len(alerts)} budget alerts")
            return alerts
            
        except Exception as e:
            logger.error(f"Error checking budget alerts: {e}")
            return []
    
    def analyze_sustained_use_discounts(self, billing_data: pd.DataFrame) -> Dict:
        """Analyze sustained use discount utilization"""
        try:
            # Filter for Compute Engine costs
            compute_data = billing_data[
                billing_data['service_name'].str.contains('Compute Engine', na=False)
            ]
            
            # Calculate sustained use discount savings
            total_compute_cost = compute_data['cost'].sum()
            
            # Extract credits (sustained use discounts)
            compute_data['credits_amount'] = compute_data['credits'].apply(
                lambda x: sum([credit.get('amount', 0) for credit in x]) if isinstance(x, list) else 0
            )
            
            sustained_use_savings = compute_data['credits_amount'].sum()
            potential_savings_rate = 0.30  # Maximum sustained use discount
            
            analysis = {
                'total_compute_cost': total_compute_cost,
                'sustained_use_savings': abs(sustained_use_savings),
                'savings_rate': abs(sustained_use_savings) / total_compute_cost if total_compute_cost > 0 else 0,
                'potential_additional_savings': total_compute_cost * potential_savings_rate - abs(sustained_use_savings),
                'optimization_opportunity': abs(sustained_use_savings) / total_compute_cost < 0.20 if total_compute_cost > 0 else False
            }
            
            logger.info(f"Sustained use discount analysis: ${abs(sustained_use_savings):.2f} savings")
            return analysis
            
        except Exception as e:
            logger.error(f"Error analyzing sustained use discounts: {e}")
            return {}
    
    def analyze_bigquery_costs(self, billing_data: pd.DataFrame) -> Dict:
        """Analyze BigQuery costs and optimization opportunities"""
        try:
            # Filter for BigQuery costs
            bq_data = billing_data[
                billing_data['service_name'].str.contains('BigQuery', na=False)
            ]
            
            if bq_data.empty:
                return {'total_cost': 0, 'optimization_opportunities': []}
            
            total_bq_cost = bq_data['cost'].sum()
            
            # Analyze by project
            project_costs = bq_data.groupby('project_id')['cost'].sum().sort_values(ascending=False)
            
            # Get BigQuery job statistics for optimization analysis
            optimization_opportunities = []
            
            for project_id in project_costs.head(5).index:
                try:
                    # Query job statistics
                    jobs_query = f"""
                    SELECT
                        job_id,
                        total_bytes_processed,
                        total_slot_ms,
                        creation_time,
                        total_bytes_billed
                    FROM `{project_id}.region-us.INFORMATION_SCHEMA.JOBS_BY_PROJECT`
                    WHERE creation_time >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 7 DAY)
                        AND total_bytes_processed > 1000000000  -- > 1GB
                    ORDER BY total_bytes_processed DESC
                    LIMIT 10
                    """
                    
                    jobs_df = self.bigquery_client.query(jobs_query).to_dataframe()
                    
                    if not jobs_df.empty:
                        avg_bytes_processed = jobs_df['total_bytes_processed'].mean()
                        if avg_bytes_processed > 10**12:  # > 1TB
                            optimization_opportunities.append({
                                'project_id': project_id,
                                'opportunity': 'Consider BigQuery flat-rate pricing',
                                'potential_savings': project_costs[project_id] * 0.3,
                                'description': 'High data processing volume detected'
                            })
                            
                except Exception as e:
                    logger.warning(f"Could not analyze BigQuery jobs for project {project_id}: {e}")
            
            analysis = {
                'total_cost': total_bq_cost,
                'top_projects': project_costs.head(5).to_dict(),
                'optimization_opportunities': optimization_opportunities,
                'average_daily_cost': total_bq_cost / 30
            }
            
            logger.info(f"BigQuery cost analysis: ${total_bq_cost:.2f} total cost")
            return analysis
            
        except Exception as e:
            logger.error(f"Error analyzing BigQuery costs: {e}")
            return {}
    
    def get_optimization_recommendations(self, billing_data: pd.DataFrame) -> List[OptimizationRecommendation]:
        """Generate optimization recommendations based on cost analysis"""
        recommendations = []
        
        try:
            # Analyze by service for optimization opportunities
            service_costs = billing_data.groupby('service_name')['cost'].sum().sort_values(ascending=False)
            
            for service, cost in service_costs.head(10).items():
                if 'Compute Engine' in service and cost > 1000:
                    # Recommend preemptible VMs
                    recommendations.append(OptimizationRecommendation(
                        resource_type='compute',
                        resource_id='all_instances',
                        project_id='multiple',
                        recommendation_type='preemptible_vms',
                        potential_savings=cost * 0.6,  # Up to 60% savings
                        confidence=0.8,
                        description='Consider using preemptible VMs for fault-tolerant workloads',
                        implementation_effort='medium'
                    ))
                    
                    # Recommend custom machine types
                    recommendations.append(OptimizationRecommendation(
                        resource_type='compute',
                        resource_id='all_instances',
                        project_id='multiple',
                        recommendation_type='custom_machine_types',
                        potential_savings=cost * 0.3,  # Up to 30% savings
                        confidence=0.9,
                        description='Use custom machine types to match exact resource requirements',
                        implementation_effort='low'
                    ))
                
                elif 'Cloud Storage' in service and cost > 500:
                    # Recommend storage lifecycle policies
                    recommendations.append(OptimizationRecommendation(
                        resource_type='storage',
                        resource_id='all_buckets',
                        project_id='multiple',
                        recommendation_type='lifecycle_policies',
                        potential_savings=cost * 0.4,  # Up to 40% savings
                        confidence=0.85,
                        description='Implement lifecycle policies to automatically transition data to cheaper storage classes',
                        implementation_effort='low'
                    ))
                
                elif 'BigQuery' in service and cost > 1000:
                    # Recommend BigQuery optimization
                    recommendations.append(OptimizationRecommendation(
                        resource_type='bigquery',
                        resource_id='all_datasets',
                        project_id='multiple',
                        recommendation_type='query_optimization',
                        potential_savings=cost * 0.35,  # Up to 35% savings
                        confidence=0.75,
                        description='Optimize queries and consider flat-rate pricing for consistent workloads',
                        implementation_effort='medium'
                    ))
            
            logger.info(f"Generated {len(recommendations)} optimization recommendations")
            return recommendations
            
        except Exception as e:
            logger.error(f"Error generating optimization recommendations: {e}")
            return []
    
    def send_alert_notification(self, alert: CostAlert):
        """Send alert notification via configured channels"""
        try:
            message = f"""
            GCP Cost Alert - {alert.severity.upper()}
            
            Alert Type: {alert.alert_type}
            Project: {alert.project_id}
            Service: {alert.service}
            Current Cost: ${alert.current_cost:.2f}
            Threshold: ${alert.threshold:.2f}
            
            {alert.message}
            
            Timestamp: {alert.timestamp}
            """
            
            # Send email notification
            if self.config.get('email_notifications', {}).get('enabled'):
                self._send_email_alert(alert, message)
            
            # Send Slack notification
            if self.config.get('slack_notifications', {}).get('enabled'):
                self._send_slack_alert(alert, message)
            
            # Create ServiceNow ticket
            if self.config.get('servicenow_integration', {}).get('enabled'):
                self._create_servicenow_ticket(alert, message)
                
        except Exception as e:
            logger.error(f"Error sending alert notification: {e}")
    
    def _send_email_alert(self, alert: CostAlert, message: str):
        """Send email alert notification"""
        try:
            email_config = self.config['email_notifications']
            
            msg = MimeMultipart()
            msg['From'] = email_config['sender']
            msg['To'] = ', '.join(email_config['recipients'])
            msg['Subject'] = f"GCP Cost Alert - {alert.severity.upper()} - {alert.project_id}"
            
            msg.attach(MimeText(message, 'plain'))
            
            server = smtplib.SMTP(email_config['smtp_server'], email_config.get('smtp_port', 587))
            server.starttls()
            server.login(email_config['username'], email_config['password'])
            server.send_message(msg)
            server.quit()
            
            logger.info(f"Email alert sent for {alert.alert_type}")
            
        except Exception as e:
            logger.error(f"Error sending email alert: {e}")
    
    def _send_slack_alert(self, alert: CostAlert, message: str):
        """Send Slack alert notification"""
        try:
            slack_config = self.config['slack_notifications']
            
            payload = {
                'text': f"GCP Cost Alert - {alert.severity.upper()}",
                'attachments': [{
                    'color': 'danger' if alert.severity == 'high' else 'warning',
                    'fields': [
                        {'title': 'Project', 'value': alert.project_id, 'short': True},
                        {'title': 'Service', 'value': alert.service, 'short': True},
                        {'title': 'Current Cost', 'value': f"${alert.current_cost:.2f}", 'short': True},
                        {'title': 'Threshold', 'value': f"${alert.threshold:.2f}", 'short': True}
                    ],
                    'text': alert.message
                }]
            }
            
            response = requests.post(slack_config['webhook_url'], json=payload)
            response.raise_for_status()
            
            logger.info(f"Slack alert sent for {alert.alert_type}")
            
        except Exception as e:
            logger.error(f"Error sending Slack alert: {e}")
    
    def _create_servicenow_ticket(self, alert: CostAlert, message: str):
        """Create ServiceNow ticket for cost alert"""
        try:
            snow_config = self.config['servicenow_integration']
            
            ticket_data = {
                'short_description': f"GCP Cost Alert - {alert.project_id}",
                'description': message,
                'urgency': '2' if alert.severity == 'high' else '3',
                'impact': '2' if alert.severity == 'high' else '3',
                'assignment_group': snow_config['assignment_group'],
                'category': 'Cloud Services',
                'subcategory': 'Cost Management'
            }
            
            auth = (snow_config['username'], snow_config['password'])
            headers = {'Content-Type': 'application/json', 'Accept': 'application/json'}
            
            response = requests.post(
                f"{snow_config['instance_url']}/api/now/table/{snow_config['table_name']}",
                auth=auth,
                headers=headers,
                json=ticket_data
            )
            response.raise_for_status()
            
            ticket_number = response.json()['result']['number']
            logger.info(f"ServiceNow ticket created: {ticket_number}")
            
        except Exception as e:
            logger.error(f"Error creating ServiceNow ticket: {e}")
    
    def generate_cost_report(self, output_format: str = 'json') -> str:
        """Generate comprehensive cost report"""
        try:
            # Get billing data
            billing_data = self.get_billing_data(days=30)
            
            # Perform analysis
            cost_trends = self.analyze_cost_trends(billing_data)
            budget_alerts = self.check_budget_alerts(billing_data)
            sustained_use_analysis = self.analyze_sustained_use_discounts(billing_data)
            bigquery_analysis = self.analyze_bigquery_costs(billing_data)
            recommendations = self.get_optimization_recommendations(billing_data)
            
            # Compile report
            report = {
                'report_date': datetime.datetime.now().isoformat(),
                'period': '30 days',
                'cost_summary': cost_trends,
                'budget_alerts': [
                    {
                        'type': alert.alert_type,
                        'severity': alert.severity,
                        'project': alert.project_id,
                        'current_cost': alert.current_cost,
                        'threshold': alert.threshold,
                        'message': alert.message
                    } for alert in budget_alerts
                ],
                'sustained_use_discounts': sustained_use_analysis,
                'bigquery_analysis': bigquery_analysis,
                'optimization_recommendations': [
                    {
                        'resource_type': rec.resource_type,
                        'recommendation': rec.recommendation_type,
                        'potential_savings': rec.potential_savings,
                        'confidence': rec.confidence,
                        'description': rec.description,
                        'effort': rec.implementation_effort
                    } for rec in recommendations
                ]
            }
            
            # Format output
            if output_format == 'json':
                return json.dumps(report, indent=2)
            elif output_format == 'html':
                return self._generate_html_report(report)
            else:
                return str(report)
                
        except Exception as e:
            logger.error(f"Error generating cost report: {e}")
            raise
    
    def _generate_html_report(self, report: Dict) -> str:
        """Generate HTML formatted cost report"""
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>GCP Cost Optimization Report</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; }}
                .header {{ background-color: #4285f4; color: white; padding: 20px; }}
                .section {{ margin: 20px 0; padding: 15px; border: 1px solid #ddd; }}
                .alert {{ background-color: #fff3cd; border-color: #ffeaa7; }}
                .recommendation {{ background-color: #d4edda; border-color: #c3e6cb; }}
                table {{ width: 100%; border-collapse: collapse; }}
                th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
                th {{ background-color: #f2f2f2; }}
            </style>
        </head>
        <body>
            <div class="header">
                <h1>GCP Cost Optimization Report</h1>
                <p>Generated: {report['report_date']}</p>
                <p>Period: {report['period']}</p>
            </div>
            
            <div class="section">
                <h2>Cost Summary</h2>
                <p><strong>Total Cost:</strong> ${report['cost_summary']['total_cost']:.2f}</p>
                <p><strong>Daily Average:</strong> ${report['cost_summary']['daily_average']:.2f}</p>
                <p><strong>Trend:</strong> {report['cost_summary']['cost_trend']}</p>
                <p><strong>Anomalies Detected:</strong> {report['cost_summary']['anomalies']}</p>
            </div>
            
            <div class="section alert">
                <h2>Budget Alerts ({len(report['budget_alerts'])})</h2>
                <table>
                    <tr><th>Project</th><th>Severity</th><th>Current Cost</th><th>Threshold</th><th>Message</th></tr>
        """
        
        for alert in report['budget_alerts']:
            html += f"""
                    <tr>
                        <td>{alert['project']}</td>
                        <td>{alert['severity']}</td>
                        <td>${alert['current_cost']:.2f}</td>
                        <td>${alert['threshold']:.2f}</td>
                        <td>{alert['message']}</td>
                    </tr>
            """
        
        html += """
                </table>
            </div>
            
            <div class="section recommendation">
                <h2>Optimization Recommendations</h2>
                <table>
                    <tr><th>Resource Type</th><th>Recommendation</th><th>Potential Savings</th><th>Confidence</th><th>Effort</th></tr>
        """
        
        for rec in report['optimization_recommendations']:
            html += f"""
                    <tr>
                        <td>{rec['resource_type']}</td>
                        <td>{rec['recommendation']}</td>
                        <td>${rec['potential_savings']:.2f}</td>
                        <td>{rec['confidence']:.0%}</td>
                        <td>{rec['effort']}</td>
                    </tr>
            """
        
        html += """
                </table>
            </div>
        </body>
        </html>
        """
        
        return html
    
    def run_continuous_monitoring(self):
        """Run continuous cost monitoring"""
        logger.info("Starting continuous cost monitoring...")
        
        try:
            while True:
                # Get current billing data
                billing_data = self.get_billing_data(days=7)  # Last 7 days for real-time monitoring
                
                # Check for budget alerts
                alerts = self.check_budget_alerts(billing_data)
                
                # Send notifications for new alerts
                for alert in alerts:
                    self.send_alert_notification(alert)
                
                # Wait for next monitoring cycle (configurable)
                import time
                monitoring_interval = self.config.get('monitoring_interval_minutes', 15) * 60
                time.sleep(monitoring_interval)
                
        except KeyboardInterrupt:
            logger.info("Continuous monitoring stopped by user")
        except Exception as e:
            logger.error(f"Error in continuous monitoring: {e}")
            raise

def main():
    """Main function for command-line usage"""
    parser = argparse.ArgumentParser(description='GCP Cost Monitoring and Optimization')
    parser.add_argument('--config', default='config/gcp_monitoring_config.json', help='Configuration file path')
    parser.add_argument('--mode', choices=['report', 'continuous', 'analyze'], default='report', help='Operation mode')
    parser.add_argument('--output-format', choices=['json', 'html'], default='json', help='Report output format')
    parser.add_argument('--project', help='Specific project to analyze')
    parser.add_argument('--days', type=int, default=30, help='Number of days to analyze')
    parser.add_argument('--detailed-analysis', action='store_true', help='Perform detailed analysis')
    
    args = parser.parse_args()
    
    try:
        monitor = GCPCostMonitor(args.config)
        
        if args.mode == 'report':
            report = monitor.generate_cost_report(args.output_format)
            print(report)
            
        elif args.mode == 'continuous':
            monitor.run_continuous_monitoring()
            
        elif args.mode == 'analyze':
            billing_data = monitor.get_billing_data(args.days)
            analysis = monitor.analyze_cost_trends(billing_data)
            print(json.dumps(analysis, indent=2))
            
    except Exception as e:
        logger.error(f"Error in main execution: {e}")
        return 1
    
    return 0

if __name__ == '__main__':
    exit(main())

